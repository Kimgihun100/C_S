export default function ChatArea() {
    return `
        <main id="chat-area">
        </main>
    `;
}