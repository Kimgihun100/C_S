export default function UserInput() {
    return `
        <footer id="user-input">
            <textarea id="message-input" placeholder="하고 싶은 어떤 말이던 다 좋아요! 하람님의 마음 속에 남겨진 모든 것을 훌훌 털어내보세요."></textarea>
            <button id="send-btn">submit</button>
        </footer>
    `;
}